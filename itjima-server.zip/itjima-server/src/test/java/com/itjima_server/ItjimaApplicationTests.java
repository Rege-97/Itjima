package com.itjima_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItjimaApplicationTests {

	@Test
	void contextLoads() {
	}

}
