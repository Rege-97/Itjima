package com.itjima_server.controller;

import com.itjima_server.common.ApiResponseDTO;
import com.itjima_server.dto.user.request.ResendPasswordResetRequestDTO;
import com.itjima_server.dto.user.request.ResendVerificationEmailRequestDTO;
import com.itjima_server.dto.user.request.TokenRefreshRequestDTO;
import com.itjima_server.dto.user.request.UserFindEmailRequestDTO;
import com.itjima_server.dto.user.request.UserFindPasswordRequestDTO;
import com.itjima_server.dto.user.request.UserLoginRequestDTO;
import com.itjima_server.dto.user.request.UserPasswordResetRequestDTO;
import com.itjima_server.dto.user.request.UserRegisterRequestDTO;
import com.itjima_server.dto.user.response.TokenResponseDTO;
import com.itjima_server.dto.user.response.UserFindEmailResponseDTO;
import com.itjima_server.dto.user.response.UserLoginResponseDTO;
import com.itjima_server.dto.user.response.UserResponseDTO;
import com.itjima_server.security.CustomUserDetails;
import com.itjima_server.service.AuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 인증/회원가입 API 클래스
 *
 * @author Rege-97
 * @since 2025-08-28
 */
@Tag(name = "Auth", description = "인증/회원가입 API")
@RestController
@RequestMapping("/api/auth/")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;


    /**
     * 신규 사용자 회원가입
     *
     * @param req 회원 가입 요청 DTO
     * @return 회원가입 결과 응답
     */
    @Operation(
            summary = "회원가입",
            description = "신규 사용자 등록"
    )
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "회원가입 성공",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = UserResponseDTO.class))),
            @ApiResponse(responseCode = "400", description = "요청 검증 실패",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "409", description = "중복 이메일/전화번호",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE))
    })
    @PostMapping("/signup")
    public ResponseEntity<?> register(@Valid @RequestBody UserRegisterRequestDTO req) {
        UserResponseDTO res = authService.register(req);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponseDTO.success(HttpStatus.CREATED.value(), "회원 가입 성공", res));
    }

    /**
     * 이메일 인증 처리
     *
     * @param token 인증할 인증번호
     * @return 인증 완료 응답
     */
    @Operation(
            summary = "이메일 인증",
            description = "회원 가입 시 보내진 인증번호로 이메일 인증"
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "인증 성공",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = ApiResponseDTO.class))),
            @ApiResponse(responseCode = "400", description = "요청 검증 실패",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "대상 없음",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "409", description = "요청 불가 상태",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE))
    })
    @GetMapping("/verify-email")
    public ResponseEntity<?> verifyEmail(@RequestParam(required = false) String token) {
        authService.verifyEmail(token);
        return ResponseEntity.status(HttpStatus.OK)
                .body(ApiResponseDTO.success(HttpStatus.OK.value(), "이메일 인증 성공"));
    }

    /**
     * 회원가입 이메일 인증 코드 재전송
     *
     * @param req 재전송 요청 DTO
     * @return 성공 메시지
     */
    @Operation(
            summary = "회원가입 인증 코드 재전송",
            description = "회원 가입 시 보내진 인증번호 재전송"
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "인증 번호 전송 성공",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = ApiResponseDTO.class))),
            @ApiResponse(responseCode = "400", description = "요청 검증 실패",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "대상 없음",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "409", description = "요청 불가 상태",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE))
    })
    @PostMapping("/verify-email/resend")
    public ResponseEntity<?> resendVerificationEmail(
            @Valid @RequestBody ResendVerificationEmailRequestDTO req) {
        authService.resendVerifyEmail(req.getEmail());
        return ResponseEntity.ok(
                ApiResponseDTO.success(HttpStatus.OK.value(), "인증 코드가 이메일로 재발송되었습니다."));
    }

    /**
     * 회원 로그인
     *
     * @param req 로그인 요청 DTO
     * @return 로그인 결과 응답
     */
    @Operation(
            summary = "로그인",
            description = "액세스/리프레시 토큰 발급"
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "로그인 성공",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = UserLoginResponseDTO.class))),
            @ApiResponse(responseCode = "400", description = "요청 검증 실패",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "401", description = "인증 실패",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE))
    })
    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody UserLoginRequestDTO req) {
        UserLoginResponseDTO res = authService.login(req);
        return ResponseEntity.status(HttpStatus.OK)
                .body(ApiResponseDTO.success(HttpStatus.OK.value(), "로그인 성공", res));
    }

    /**
     * 카카오 로그인
     *
     * @param code 카카오에서 받은 인가 코드
     * @return 로그인 결과 응답
     */
    @Operation(
            summary = "카카오 소셜 로그인",
            description = "카카오로부터 받은 인증 코드로 로그인/회원가입을 처리"
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "로그인 성공",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = UserLoginResponseDTO.class))),
            @ApiResponse(responseCode = "400", description = "요청 검증 실패",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "500", description = "카카오 서버 요청 오류",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE))
    })
    @GetMapping("/kakao")
    public ResponseEntity<?> kakaoLogin(@RequestParam String code) {
        UserLoginResponseDTO res = authService.kakaoLogin(code);
        return ResponseEntity.status(HttpStatus.OK)
                .body(ApiResponseDTO.success(HttpStatus.OK.value(), "카카오 로그인 성공", res));
    }

    /**
     * 액세스 토큰 재발급
     *
     * @param req 리프레쉬 토큰 DTO
     * @return 재발급 결과 응답
     */
    @Operation(
            summary = "토큰 재발급",
            description = "유효한 리프레시 토큰으로 액세스 토큰 재발급"
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "재발급 성공",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = TokenResponseDTO.class))),
            @ApiResponse(responseCode = "400", description = "요청 검증 실패",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "401", description = "리프레시 토큰 무효/만료",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE))
    })
    @PostMapping("/refresh")
    public ResponseEntity<?> refreshAccessToken(@Valid @RequestBody TokenRefreshRequestDTO req) {
        TokenResponseDTO res = authService.refreshAccessToken(req);
        return ResponseEntity.status(HttpStatus.OK)
                .body(ApiResponseDTO.success(HttpStatus.OK.value(), "토큰 재발급 성공", res));
    }

    /**
     * 로그아웃
     *
     * @param user 토큰 인증된 사용자
     * @return 로그아웃 결과 메세지
     */
    @Operation(
            summary = "로그아웃",
            description = "리프레시 토큰 폐기",
            security = {@SecurityRequirement(name = "bearerAuth")} // Swagger UI의 Authorize 버튼과 연동
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "로그아웃 성공",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "401", description = "인증 필요",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE))
    })
    @PostMapping("/logout")
    public ResponseEntity<?> logout(@AuthenticationPrincipal CustomUserDetails user) {
        authService.logout(user.getId());
        return ResponseEntity.status(HttpStatus.OK)
                .body(ApiResponseDTO.success(HttpStatus.OK.value(), "로그아웃 성공"));
    }

    /**
     * 이메일 찾기
     *
     * @param req 이메일을 찾기 위한 정보
     * @return 마스킹된 이메일
     */
    @Operation(
            summary = "이메일 찾기",
            description = "사용자의 이메일 찾기"
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "이메일 찾기 성공",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = UserFindEmailResponseDTO.class))),
            @ApiResponse(responseCode = "400", description = "요청 검증 실패",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE))
    })
    @PostMapping("/find-email")
    public ResponseEntity<?> findEmail(@Valid @RequestBody UserFindEmailRequestDTO req) {
        UserFindEmailResponseDTO res = authService.findEmail(req);
        return ResponseEntity.status(HttpStatus.OK)
                .body(ApiResponseDTO.success(HttpStatus.OK.value(), "이메일 찾기 성공", res));
    }

    /**
     * 비밀번호 찾기(인증코드 발송)
     *
     * @param req 비밀번호를 찾기 위한 정보
     * @return 인증코드 발송 메세지
     */
    @Operation(
            summary = "비밀번호 찾기(인증코드 발송)",
            description = "사용자의 비밀번호 찾기(인증번호 발송)"
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "인증코드 발송",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = ApiResponseDTO.class))),
            @ApiResponse(responseCode = "400", description = "요청 검증 실패",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE))
    })
    @PostMapping("/password-reset/request")
    public ResponseEntity<?> findPassword(@Valid @RequestBody UserFindPasswordRequestDTO req) {
        authService.sendPasswordResetCode(req);
        return ResponseEntity.status(HttpStatus.OK)
                .body(ApiResponseDTO.success(HttpStatus.OK.value(), "인증코드 발송 완료"));
    }

    /**
     * 비밀번호 재설정
     *
     * @param req 인증코드와 새 비밀번호
     * @return 비밀번호 변경 완료 메세지
     */
    @Operation(
            summary = "비밀번호 재설정",
            description = "인증코드 검증 후 비밀번호 재설정"
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "비밀번호 변경 완료",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = ApiResponseDTO.class))),
            @ApiResponse(responseCode = "400", description = "요청 검증 실패",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "409", description = "요청 불가 상태",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE))
    })
    @PostMapping("/password-reset/confirm")
    public ResponseEntity<?> resetPassword(@Valid @RequestBody UserPasswordResetRequestDTO req) {
        authService.passwordReset(req.getCode(), req.getPassword());
        return ResponseEntity.status(HttpStatus.OK)
                .body(ApiResponseDTO.success(HttpStatus.OK.value(), "비밀번호 변경 완료"));
    }


    /**
     * 비밀번호 재설정 인증 코드 재전송
     *
     * @param req 재전송 요청 DTO
     * @return 성공 메시지
     */
    @Operation(
            summary = "비밀번호 재설정 인증 코드 재전송",
            description = "비밀번호 재설정 시 보내진 인증번호 재전송"
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "인증 번호 전송 성공",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = ApiResponseDTO.class))),
            @ApiResponse(responseCode = "400", description = "요청 검증 실패",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "대상 없음",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "409", description = "요청 불가 상태",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE))
    })
    @PostMapping("/password-reset/resend")
    public ResponseEntity<?> resendPasswordReset(
            @Valid @RequestBody ResendPasswordResetRequestDTO req) {
        authService.resendPasswordReset(req.getEmail());
        return ResponseEntity.ok(
                ApiResponseDTO.success(HttpStatus.OK.value(), "인증 코드가 이메일로 재발송되었습니다."));
    }
}
