package com.itjima_server.exception.agreement;

import com.itjima_server.exception.common.NotInsertException;

public class NotInsertAgreementException extends NotInsertException {

    public NotInsertAgreementException(String message) {
        super(message);
    }
}
