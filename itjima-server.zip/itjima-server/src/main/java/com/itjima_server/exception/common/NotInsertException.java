package com.itjima_server.exception.common;

public class NotInsertException extends RuntimeException {

    public NotInsertException(String message) {
        super(message);
    }
}
