package com.itjima_server.exception.item;

import com.itjima_server.exception.common.NotInsertException;

public class NotInsertItemException extends NotInsertException {

    public NotInsertItemException(String message) {
        super(message);
    }
}
