package com.itjima_server.exception.common;

public class UpdateFailedException extends RuntimeException {

    public UpdateFailedException(String message) {
        super(message);
    }
}
