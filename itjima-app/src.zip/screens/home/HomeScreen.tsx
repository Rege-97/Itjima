import React, { useEffect, useState } from "react";
import { SafeAreaView, ScrollView, View, Image, StyleSheet } from "react-native";
import { Card, Text, Divider, ActivityIndicator } from "react-native-paper";
import { getDashboardApi } from "../../api/dashboards"; // 경로는 프로젝트 구조에 맞게 조정

export default function HomeScreen() {
  const [data, setData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchDashboard = async () => {
      try {
        const res = await getDashboardApi();
        setData(res.data); // { counts, comingReturns, overdues }
      } catch (e: any) {
        setError("대시보드 데이터를 불러오지 못했습니다.");
      } finally {
        setIsLoading(false);
      }
    };
    fetchDashboard();
  }, []);

  if (isLoading) {
    return (
      <SafeAreaView style={styles.center}>
        <ActivityIndicator size="large" />
        <Text>불러오는 중...</Text>
      </SafeAreaView>
    );
  }

  if (error) {
    return (
      <SafeAreaView style={styles.center}>
        <Text>{error}</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <ScrollView contentContainerStyle={styles.container}>
        {/* Counts */}
        <Card style={styles.card}>
          <Card.Content>
            <Text variant="titleMedium">계약 요약</Text>
            <Divider style={styles.divider} />
            <Text>
              역할: {data.counts.role} | 개수: {data.counts.count}
            </Text>
          </Card.Content>
        </Card>

        {/* Coming Returns */}
        {data.comingReturns && (
          <Card style={styles.card}>
            <Card.Content>
              <Text variant="titleMedium">곧 반환 예정</Text>
              <Divider style={styles.divider} />
              <View style={styles.row}>
                <Image
                  source={{ uri: data.comingReturns.itemFileUrl }}
                  style={styles.image}
                />
                <View style={{ flex: 1 }}>
                  <Text>{data.comingReturns.itemTitle}</Text>
                  <Text>{data.comingReturns.itemDescription}</Text>
                  <Text>금액: {data.comingReturns.amount}원</Text>
                  <Text>반환일: {data.comingReturns.dueAt}</Text>
                  <Text>D-{data.comingReturns.daysLeft}</Text>
                </View>
              </View>
            </Card.Content>
          </Card>
        )}

        {/* Overdues */}
        {data.overdues && (
          <Card style={styles.card}>
            <Card.Content>
              <Text variant="titleMedium">연체</Text>
              <Divider style={styles.divider} />
              <View style={styles.row}>
                <Image
                  source={{ uri: data.overdues.itemFileUrl }}
                  style={styles.image}
                />
                <View style={{ flex: 1 }}>
                  <Text>{data.overdues.itemTitle}</Text>
                  <Text>{data.overdues.itemDescription}</Text>
                  <Text>금액: {data.overdues.amount}원</Text>
                  <Text>반환일: {data.overdues.dueAt}</Text>
                  <Text>연체일: {data.overdues.overDays}일</Text>
                </View>
              </View>
            </Card.Content>
          </Card>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
    gap: 16,
  },
  card: {
    borderRadius: 12,
    elevation: 2,
  },
  divider: {
    marginVertical: 8,
  },
  row: {
    flexDirection: "row",
    gap: 12,
    marginTop: 8,
  },
  image: {
    width: 80,
    height: 80,
    borderRadius: 8,
    marginRight: 8,
  },
  center: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
});
